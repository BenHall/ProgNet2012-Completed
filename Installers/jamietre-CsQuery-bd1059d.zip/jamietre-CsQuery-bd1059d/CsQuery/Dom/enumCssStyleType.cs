﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery
{
    public enum CssStyleType
    {
        Unit = 1,
        Option = 2,
        UnitOption=3,
        Composite = 4,
        Color = 5,
        Font = 6,
        Url=7,
        String=8
    }

}
