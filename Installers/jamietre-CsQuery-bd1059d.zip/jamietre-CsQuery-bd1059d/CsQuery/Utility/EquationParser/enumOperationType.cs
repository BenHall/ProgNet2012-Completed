﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery.Utility.EquationParser
{
    public enum OperationType
    {
        Addition=1,
        Subtraction=2,
        Multiplication=3,
        Division=4,
        Modulus = 5,
        Power=6
    }
}
