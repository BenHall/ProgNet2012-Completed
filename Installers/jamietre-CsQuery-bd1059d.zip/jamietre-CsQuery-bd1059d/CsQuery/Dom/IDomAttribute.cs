﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery
{
    // marker
    public interface IDomAttribute: IDomNode, IDomIndexedNode
    {
        
    }
}
