﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery.Implementation
{

    //public class DomAttribute: IDomNode<DomAttribute>
    //{
    //    ushort TokenId;
    //    public DomAttribute(string name, string value)
    //    {
    //        if (String.IsNullOrEmpty(name))
    //        {
    //            throw new InvalidOperationException("Node must have a name");
    //        }
    //        NodeName = name;
    //        NodeValue = value;
    //    }

    //    public NodeType NodeType
    //    {
    //        get { return NodeType.ATTRIBUTE_NODE; }
    //    }

    //    public DomAttribute Clone()
    //    {
    //        DomAttribute clone = new DomAttribute(NodeName,NodeValue);
    //        return clone;
    //    }

    //    public string NodeName
    //    {
    //        get;
    //        set;
    //    }

    //    public string NodeValue
    //    {
    //       get;set;
        
    //    }

    //    public bool HasChildren
    //    {
    //        get { return false; }
    //    }

    //    public IEnumerable<IDomElement> ChildElements
    //    {
    //        get { return null; }
    //    }

    //    public INodeList ChildNodes
    //    {
    //        get { return null; }
    //    }

    //    public bool Complete
    //    {
    //        get { return true; }
    //    }

    //    public string Render()
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void Render(StringBuilder sb)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void Render(StringBuilder sb, DomRenderingOptions options)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void Remove()
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public bool IsIndexed
    //    {
    //        get { return true; }
    //    }

    //    public int Index
    //    {
    //        get { return 0; }
    //    }

    //    public string PathID
    //    {
    //        get { throw new NotImplementedException(); }
    //    }

    //    public string Path
    //    {
    //        get { throw new NotImplementedException(); }
    //    }

    //    public bool IsDisconnected
    //    {
    //        get { throw new NotImplementedException(); }
    //    }
    //}
}
