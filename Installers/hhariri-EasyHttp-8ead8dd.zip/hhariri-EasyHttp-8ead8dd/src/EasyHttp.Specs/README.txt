﻿[Note: These are integration tests]

To run the tests you need CouchDB. 

1. Fire up CouchDB on localhost:5984 (If you really need to, you can change it in App.Config)
2. Create a database called easyhttp. 


(I'll make this part of the test setup, but for now it's manual)