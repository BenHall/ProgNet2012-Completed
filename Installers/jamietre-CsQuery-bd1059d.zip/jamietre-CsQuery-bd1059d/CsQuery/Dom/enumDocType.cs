﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery
{
    public enum DocType
    {
        HTML5 = 1,
        HTML4 = 2,
        XHTML = 3,
        Unknown = 4
    }
}
