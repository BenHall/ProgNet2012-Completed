﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery
{
    /// <summary>
    /// Special element for the text contents of SCRIPT & TEXTAREA objects
    /// </summary>

    public interface IDomInnerText : IDomText
    {

    }
}
